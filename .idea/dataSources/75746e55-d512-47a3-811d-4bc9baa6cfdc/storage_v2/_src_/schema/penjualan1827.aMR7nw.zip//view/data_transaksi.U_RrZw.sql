create view data_transaksi as
select `penjualan1827`.`transaksi1827`.`kode_transaksi`                                 AS `kode_transaksi`,
       `penjualan1827`.`transaksi1827`.`tgl_transaksi`                                  AS `tgl_transaksi`,
       ifnull(`penjualan1827`.`pelanggan1827`.`nama`, 'Data Pelanggan Belum Terdaftar') AS `nama`
from (`penjualan1827`.`transaksi1827`
         left join `penjualan1827`.`pelanggan1827` on (`penjualan1827`.`pelanggan1827`.`id_pelanggan` =
                                                       `penjualan1827`.`transaksi1827`.`id_pelanggan`));

