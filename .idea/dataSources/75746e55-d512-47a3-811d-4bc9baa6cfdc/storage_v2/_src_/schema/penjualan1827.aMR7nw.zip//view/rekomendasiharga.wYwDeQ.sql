create view rekomendasiharga as
select `penjualan1827`.`barang1827`.`id_barang`                             AS `id_barang`,
       `penjualan1827`.`barang1827`.`nama`                                  AS `nama`,
       `penjualan1827`.`barang1827`.`stok`                                  AS `stok`,
       if(`penjualan1827`.`barang1827`.`stok` < 50, 'naik_harga',
          if(`penjualan1827`.`barang1827`.`stok` < 100, 'tetap', 'diskon')) AS `statusRekomendasi`,
       `penjualan1827`.`barang1827`.`harga`                                 AS `harga`,
       case
           when `penjualan1827`.`barang1827`.`stok` < 50 then `penjualan1827`.`barang1827`.`harga` * 2
           when `penjualan1827`.`barang1827`.`stok` < 100 then `penjualan1827`.`barang1827`.`harga`
           else `penjualan1827`.`barang1827`.`harga` / 2 end                AS `rekomendasiHarga`
from `penjualan1827`.`barang1827`;

