create
    definer = root@localhost procedure listBarangTidakLaku(IN stokMInPersen int)
BEGIN 
		declare stokMax, stokMin int;
		set stokMax=stokMax();
		set stokMin=stokMInPersen/100 * stokMax;
		select * from barang1827
			where stok<stokMin;
	END;

