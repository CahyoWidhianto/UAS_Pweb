create
    definer = root@localhost procedure gajikaryawan(IN gajiP int)
BEGIN 
		SELECT * FROM karyawan1827
			WHERE gaji>gajiP;
	END;

