create
    definer = root@localhost procedure listBarangStok(IN stokbrg int)
BEGIN 
			select * from barang1827
			where stok>stokbrg;
	END;

