create
    definer = root@localhost function simulasiDiskon(diskon int) returns int
BEGIN
		RETURN diskon*2;
	END;

