create view re_stok as
select `penjualan1827`.`suplier1827`.`nama`   AS `nama`,
       `penjualan1827`.`suplier1827`.`alamat` AS `alamat`,
       `penjualan1827`.`barang1827`.`stok`    AS `stok`
from (`penjualan1827`.`barang1827`
         left join `penjualan1827`.`suplier1827`
                   on (`penjualan1827`.`barang1827`.`id_suplier` = `penjualan1827`.`suplier1827`.`id_suplier`))
where `penjualan1827`.`barang1827`.`stok` < 100;

