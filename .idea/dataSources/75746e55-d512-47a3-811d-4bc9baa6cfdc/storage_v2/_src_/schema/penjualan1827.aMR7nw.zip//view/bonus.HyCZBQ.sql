create view bonus as
select `penjualan1827`.`karyawan1827`.`id_karyawan`                  AS `id_karyawan`,
       `penjualan1827`.`karyawan1827`.`nama`                         AS `nama`,
       `penjualan1827`.`karyawan1827`.`gaji`                         AS `gaji`,
       case
           when `penjualan1827`.`karyawan1827`.`gaji` < 1000000 then `penjualan1827`.`karyawan1827`.`gaji` * 50 / 100
           when `penjualan1827`.`karyawan1827`.`gaji` < 5000000 then `penjualan1827`.`karyawan1827`.`gaji` * 30 / 100
           else `penjualan1827`.`karyawan1827`.`gaji` * 10 / 100 end AS `Bonus`
from `penjualan1827`.`karyawan1827`;

