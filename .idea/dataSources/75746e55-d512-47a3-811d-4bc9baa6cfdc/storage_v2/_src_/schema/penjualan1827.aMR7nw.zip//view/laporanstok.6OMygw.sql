create view laporanstok as
select `penjualan1827`.`barang1827`.`id_barang` AS `id_barang`,
       `penjualan1827`.`barang1827`.`nama`      AS `nama`,
       `penjualan1827`.`barang1827`.`stok`      AS `stok`,
       case
           when `penjualan1827`.`barang1827`.`stok` < 50 then 'sedikit'
           when `penjualan1827`.`barang1827`.`stok` < 100 then 'cukup'
           else 'lebih' end                     AS `keterangan`
from `penjualan1827`.`barang1827`;

