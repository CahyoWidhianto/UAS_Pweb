create view laporangajikaryawan as
select `penjualan1827`.`karyawan1827`.`id_karyawan` AS `id_karyawan`,
       `penjualan1827`.`karyawan1827`.`nama`        AS `nama`,
       `penjualan1827`.`karyawan1827`.`gaji`        AS `gaji`,
       case
           when `penjualan1827`.`karyawan1827`.`gaji` < 1000000 then 'kecil'
           when `penjualan1827`.`karyawan1827`.`gaji` < 6000000 then 'cukup'
           else 'besar' end                         AS `klasifikasi`
from `penjualan1827`.`karyawan1827`;

