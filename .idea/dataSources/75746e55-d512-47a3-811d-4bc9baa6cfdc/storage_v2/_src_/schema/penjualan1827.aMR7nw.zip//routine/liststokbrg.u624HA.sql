create
    definer = root@localhost procedure liststokbrg(IN stokbrg int)
BEGIN 
			SELECT 
				nama,
				stok,
				harga
			FROM 
				barang1827
			WHERE 
				stok>stokbrg;
	END;

