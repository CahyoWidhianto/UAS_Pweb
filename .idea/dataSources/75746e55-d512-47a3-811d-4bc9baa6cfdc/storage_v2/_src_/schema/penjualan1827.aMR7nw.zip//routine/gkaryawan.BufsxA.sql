create
    definer = root@localhost procedure gkaryawan(IN gajiK int)
BEGIN 
		SELECT * FROM karyawan1827
			WHERE gaji<gajiK;
	END;

