create
    definer = root@localhost function tambah(angka1 int, angka2 int) returns int
BEGIN
		RETURN angka1 + angka2;
	END;

