create
    definer = root@localhost function naikGaji(gaji int) returns int
BEGIN
		RETURN (gaji*50/100)+gaji;
	END;

