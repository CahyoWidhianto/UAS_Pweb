create
    definer = root@localhost function hargaMax() returns decimal
BEGIN 
		RETURN (select MAX(harga) 
			from barang1827);
	END;

