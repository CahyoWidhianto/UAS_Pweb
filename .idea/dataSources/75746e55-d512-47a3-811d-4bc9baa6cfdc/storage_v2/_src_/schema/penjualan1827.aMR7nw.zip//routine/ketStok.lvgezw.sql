create
    definer = root@localhost procedure ketStok()
BEGIN 
		SELECT 
			id_barang,
			nama,
			stok,
				IF(stok < 50,'sedikit', 
				IF(stok < 100, 'cukup','kebanyakan'))
				AS keterangan
		FROM 
			barang1827;
	END;

