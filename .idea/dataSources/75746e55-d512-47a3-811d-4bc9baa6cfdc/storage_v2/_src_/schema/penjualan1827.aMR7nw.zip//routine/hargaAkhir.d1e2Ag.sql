create
    definer = root@localhost function hargaAkhir(harga int, diskon int) returns decimal
begin
		return harga-(harga*diskon/100);
	end;

