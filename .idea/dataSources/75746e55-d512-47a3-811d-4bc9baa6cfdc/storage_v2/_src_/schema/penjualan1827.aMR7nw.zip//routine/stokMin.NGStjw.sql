create
    definer = root@localhost function stokMin() returns decimal
BEGIN 
		RETURN (SELECT Min(stok) 
			FROM barang1827);
	END;

