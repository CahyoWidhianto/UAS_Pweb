create view gapernah_beli_huuu as
select `penjualan1827`.`pelanggan1827`.`id_pelanggan`    AS `id_pelanggan`,
       `penjualan1827`.`pelanggan1827`.`nama`            AS `nama`,
       `penjualan1827`.`pelanggan1827`.`jenis_pelanggan` AS `jenis_pelanggan`
from (`penjualan1827`.`pelanggan1827`
         left join `penjualan1827`.`transaksi1827`
                   on (`penjualan1827`.`transaksi1827`.`id_pelanggan` = `penjualan1827`.`pelanggan1827`.`id_pelanggan`))
where `penjualan1827`.`transaksi1827`.`id_pelanggan` is null;

