create
    definer = root@localhost function hargaDiskon(diskon decimal, harga decimal) returns decimal(10, 8)
begin
		return harga * diskon/100;
	end;

