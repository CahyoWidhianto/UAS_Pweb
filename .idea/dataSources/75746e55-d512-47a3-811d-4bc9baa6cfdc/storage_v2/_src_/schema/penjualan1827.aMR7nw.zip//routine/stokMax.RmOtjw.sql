create
    definer = root@localhost function stokMax() returns decimal
BEGIN 
		RETURN (SELECT MAX(stok) 
			FROM barang1827);
	END;

