create
    definer = root@localhost function hargaAkhirSimulasiDiskon(diskon int, harga int) returns int
BEGIN
		RETURN harga-(((diskon*2)/100)*harga);
	END;

