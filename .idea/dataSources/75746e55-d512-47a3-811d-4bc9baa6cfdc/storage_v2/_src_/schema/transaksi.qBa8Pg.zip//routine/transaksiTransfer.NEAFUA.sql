create
    definer = root@localhost procedure transaksiTransfer(IN rekasal varchar(20), IN rektujuan varchar(20),
                                                         IN jumlah int, IN tgl date)
BEGIN

Start Transaction;

	insert into pindahbuku1827 values
	(rekasal, rektujuan, jumlah, tgl);

	update rekening1827 set saldo = saldo - jumlah where no_rekening = rek_asal;

	update rekening1827 set saldo = saldo + jumlah where no_rekening = rek_tujuan;

Commit;

END;

